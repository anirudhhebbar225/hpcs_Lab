OpenMP Lab Programs (C)

Compile each program in Ubuntu:
    gcc -fopenmp filename.c -o program
    ./program

Files:
1. Parallel merge sort using sections
2. Matrix row and column maximum using parallel for
3. Prime numbers with serial and parallel timing
4. Pi calculation using reduction
5. Factorials calculated in parallel

Note: Program 2 and 3 use critical sections around printf so output does not interleave.
